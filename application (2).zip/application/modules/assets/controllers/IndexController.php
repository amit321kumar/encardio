<?php


class Assets_IndexController extends Zend_Controller_Action
{
	public function preDispatch()
	{
		
	}
	
	/**
	 * default action
	 */
	public function indexAction()
	{
		//echo " echoed";exit;

	}	
}

