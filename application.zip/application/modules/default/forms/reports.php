<?php

class Default_Form_reports extends Zend_Form
{
	public function init()
	{
	   
	}
}
?>